package AppClimate;

import java.util.Random;

public class Humidity extends ClimateMeasurement {
	private double humPerc;
	//Constructor
	public Humidity() {
		super();
		Random r = new Random();
		this.setHumPerc(100 * r.nextDouble());
	}
	//Getter- Setter for the humidity percentage
	public double getHumPerc() {
		return humPerc;
	}

	public void setHumPerc(double humPerc) {
		this.humPerc = humPerc;
	}
	
}
