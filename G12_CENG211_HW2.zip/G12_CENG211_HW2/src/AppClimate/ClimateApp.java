package AppClimate;

public class ClimateApp {

	public static void main(String[] args) {
		
		// Create an instance of the ClimateRecord class
		ClimateRecord climate = new ClimateRecord();
		
		// Call the menu method to start the climate application
		climate.menu();

	}

}