package AppClimate;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class FileIO {
	
	public static ArrayList<String> readCity() {
		//Creating a ArrayList for the cities
		ArrayList<String> namesCity = new ArrayList<String>();
		
		try {
            FileReader fileReader = new FileReader("countries_and_cities.csv");
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String line;

            while ((line = bufferedReader.readLine()) != null) {
            	//Filling namesCity with cities in the csv file
                String[] values = line.split(", ");
                namesCity.add(values[1]);
                namesCity.add(values[2]);
                namesCity.add(values[3]);
                
                }
            bufferedReader.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return namesCity;
	}
	
public static ArrayList<String> readCountry() {
		//Creating a ArrayList for the countries

		ArrayList<String> namesCountry = new ArrayList<String>();
		
		try {
            FileReader fileReader = new FileReader("countries_and_cities.csv");
            BufferedReader bufferedReader = new BufferedReader(fileReader);

            String line;

            while ((line = bufferedReader.readLine()) != null) {
            	//Filling namesCountry with countries in the csv file
                String[] values = line.split(",");
                namesCountry.add(values[0]);
                
                }
            bufferedReader.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return namesCountry;
	}
	
}
