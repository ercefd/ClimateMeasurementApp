package AppClimate;

import java.util.ArrayList;

public class Country {
	String name;
	//Creating ArrayList of class type Temperature
	public ArrayList<Temperature> tempArr = new ArrayList<Temperature>();
	//Constructor with name parameter
	public Country(String name) {
		//Adding Temperature objects to the tempArr for each month
		for(int i = 0; i<36 ; i++) {
			Temperature temp = new Temperature();
			tempArr.add(temp);
		}
		this.name = name;
	}
	//Getter method for name
	public String getName() {
		return name;
	}
	
	
}
