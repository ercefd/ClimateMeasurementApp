package AppClimate;

import java.util.ArrayList;

public class City {
	// City name
	String name;
	 
	// ArrayList to store ClimateMeasurement objects
	public ArrayList<ClimateMeasurement> allVar = new ArrayList<ClimateMeasurement>();
	 
		// Getter method for the city name
		public String getName() {
			return name;
	}
		// Constructor for the City class
		public City(String name) {
		this.name = name;
		// Adding Temperature objects  to the ArrayList	
		for(int i = 0; i<36 ; i++) {
			Temperature temp = new Temperature();
			
			allVar.add(temp);

		}
		// Adding WindSpeed objects to the ArrayList
		for(int i = 0; i<36 ; i++) {
					WindSpeed wind = new WindSpeed();

					allVar.add(wind);
					
		}
		// Adding humidity objects to the ArrayList
		for(int i = 0; i<36 ; i++) {
			Humidity humid = new Humidity();

			allVar.add(humid);

		}
		// Adding RadiationAbsorbtion objects to the ArrayList
		for(int i = 0; i<36 ; i++) {
			RadiationAbsorbtion rad = new RadiationAbsorbtion();

			allVar.add(rad);
			
		}
	}
	
}
