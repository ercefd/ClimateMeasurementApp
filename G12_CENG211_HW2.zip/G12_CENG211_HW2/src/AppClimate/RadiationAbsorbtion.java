package AppClimate;

import java.util.Random;

public class RadiationAbsorbtion extends ClimateMeasurement {
	private RadiationIndensity randInd;
	private String randIndString;
	private double unitAbsVal;
	
	// Enumeration for radiation indensity levels
	enum RadiationIndensity{
		Low, Medium, High
	}
	//Constructor
	public RadiationAbsorbtion() {
		Random r = new Random();
		// Setting random radiation intensity, unit absorption value
		this.setRandInd(randomIndensityGenerator());
		this.setUnitAbsVal(20 * r.nextDouble());
		this.setRandIndString(this.getRandInd().toString());
	}
	
	

	public RadiationIndensity randomIndensityGenerator(){
		return RadiationIndensity.values()[new Random().nextInt(RadiationIndensity.values().length)];
	}
	//Getters-Setters for randIndString and unitAbsVal
	public String getRandIndString() {
		return randIndString;
	}

	public void setRandIndString(String randIndString) {
		this.randIndString = randIndString;
	}
	
	public RadiationIndensity getRandInd() {
		return randInd;
	}

	public void setRandInd(RadiationIndensity randInd) {
		this.randInd = randInd;
	}

	public double getUnitAbsVal() {
		return unitAbsVal;
	}

	public void setUnitAbsVal(double unitAbsVal) {
		this.unitAbsVal = unitAbsVal;
	}
}
