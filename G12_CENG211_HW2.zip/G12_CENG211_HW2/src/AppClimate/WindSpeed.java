package AppClimate;

import java.util.Random;

public class WindSpeed extends ClimateMeasurement {
	// Fields to store wind speed measurements in different units

	private double mPerSec;		// Wind speed in meters per second
	private double kmPerHour;	// Wind speed in kilometers per hour
	
	// Constructor
	public WindSpeed() {
		// Call the superclass constructor
		super();
		
		// Generate a random wind speed in meters per second
		Random r = new Random();
		this.setmPerSec(113.2 * r.nextDouble());
		
		// Calculate and set corresponding wind speed in kilometers per hour
		this.setKmPerHour(this.getmPerSec() * 3.6);
	}
	
	
	// Getter and setter methods for wind speed in meters per second
	public double getmPerSec() {
		return mPerSec;
	}

	public void setmPerSec(double mPerSec) {
		this.mPerSec = mPerSec;
	}
	
	
	 // Getter and setter methods for wind speed in kilometers per hour
	public double getKmPerHour() {
		return kmPerHour;
	}

	public void setKmPerHour(double kmPerHour) {
		this.kmPerHour = kmPerHour;
	}
	
}