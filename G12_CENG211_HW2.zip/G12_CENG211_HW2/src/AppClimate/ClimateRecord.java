package AppClimate;

import java.util.ArrayList;
import java.util.Scanner;

public class ClimateRecord {
	//Creating ArrayLists to store the objects of Country and City classes
	ArrayList<City> cityArrList = new ArrayList<City>();
	ArrayList<Country> countryArrList = new ArrayList<Country>();
	
	public ClimateRecord() {
		//Adding the cities and countries to ArrayLists 
		ArrayList<String> cityNames = FileIO.readCity();
		ArrayList<String> countryNames = FileIO.readCountry();
		//Adding cities in the cityNames to the cityArrList
		for(String i: cityNames) {
			City ci = new City(i);
			cityArrList.add(ci);
		}
		//Adding countries in the cityNames to the cityArrList
		for(String j: countryNames) {
			Country cou = new Country(j);
			countryArrList.add(cou);
		}
	}
	//Creating a menu which have all six queries
	public void menu() {
		boolean situation = true;
		while(situation) {
			System.out.println(""
					+ "[1] Calculate average temperature for a country according to temperature unit and year.\r\n"
					+ "[2] Calculate average temperature for a city according to temperature unit and year.\r\n"
					+ "[3] Calculate average wind speed for a city according to speed unit and year.\r\n"
					+ "[4] Calculate average humidity of a city for every year.\r\n"
					+ "[5] Count how many times a year a specific radiation intensity value appears.\r\n"
					+ "[6] Calculate the “felt temperature” value for a specific month.\r\n"
					+ "[7] Exit the application."
					+ "");
			Scanner scan = new Scanner(System.in);
			System.out.println("Please select an option : ");
			int scanned = scan.nextInt();
			while((0 > scanned)||(scanned > 7)) {
				System.out.println("*Please select an option in given range!*");
				break;
			}
			switch(scanned) {
			case(1):
				System.out.println("Average is : " + firstOpt());
				System.out.println("****");
				break;
			case(2):
				System.out.println("Average is : " + secondOpt());
			System.out.println("****");
				break;
			case(3):
				System.out.println("Average is : " + thirdOpt());
			System.out.println("****");
				break;
			case(4):
				System.out.println("Average is : " + fourthOpt());
			System.out.println("****");
				break;
			case(5):
				System.out.println("Number is : " + fifthOpt());
			System.out.println("****");
				break;
			case(6):
				System.out.println("Felt temperature is : " + sixthOpt());
			System.out.println("****");
				break;
			case(7):
				System.out.println("Program is closing...");
				situation = false;
				break;
			}
		}
	}
	//First Query
	private double firstOpt() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Select country");
		String countrySelect = scan.next();
		System.out.println("[1]Celcius [2]Fahrenheit [3]Kelvin");
		int degree = scan.nextInt();
		System.out.println("[1]2020 [2]2021 [3]2022");
		int year = scan.nextInt();
		double total = 0;
		boolean inside = false;
		// Temperature(Kelvin,Fahrenheit,Celcius) for the Countries
		for(Country c: this.countryArrList) {
			if(countrySelect.equals(c.getName())) {
				inside = true;
				for(Temperature t: c.tempArr) {
					switch(degree) {
					case(1):
						if(t.getYear() == 2019+year) {
						total += t.getCelciusMeasurement();
						}
						break;
					case(2):
						if(t.getYear() == 2019+year) {
						total += t.getFahrenheitMeasurement();
						}
						break;
					case(3):
						if(t.getYear() == 2019+year) {
						total += t.getKelvinMeasurement();
						}
						break;
					}
				}
		}
		}
		if(!(inside)) {
			System.out.println("Name is invalid! So empty value is : ");
		}
		return (total/12);
		
	}
	//Second Query
	private double secondOpt() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Select city");
		String citySelect = scan.next();
		System.out.println("[1]Celcius [2]Fahrenheit [3]Kelvin");
		int degree = scan.nextInt();
		System.out.println("[1]2020 [2]2021 [3]2022");
		int year = scan.nextInt();
		double total = 0;
		boolean inside = false;
		// Temperature(Kelvin,Fahrenheit,Celcius) for the Cities
		for(City c: this.cityArrList) {
			if(citySelect.equals(c.getName())) {
				inside = true;
				for(int i = 0; i<144; i++) {
					if(c.allVar.get(i).getClass() == c.allVar.get(0).getClass()) {
						Temperature t = (Temperature) c.allVar.get(i);
						switch(degree) {
						case(1):
							if(t.getYear() == 2019+year) {
							total += t.getCelciusMeasurement();
							}
							break;
						case(2):
							if(t.getYear() == 2019+year) {
							total += t.getFahrenheitMeasurement();
							}
							break;
						case(3):
							if(t.getYear() == 2019+year) {
							total += t.getKelvinMeasurement();
							}
							break;
						}
					}
				}
		}
		}
		if(!(inside)) {
			System.out.println("Name is invalid! So empty value is : ");
		}
		return (total/12);
	}
	//Third Query
	private double thirdOpt() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Select city");
		String citySelect = scan.next();
		System.out.println("[1]Meter/Second [2]Km/Hour");
		int unitSpeed = scan.nextInt();
		System.out.println("Select month");
		String month = scan.next();
		double total = 0;
		boolean inside = false;
		//Wind Speed for the Cities(m/s,km/h)
		for(City c: this.cityArrList) {
			if(citySelect.equals(c.getName())) {
				inside = true;
				for(int i = 0; i<144; i++) {
					if(c.allVar.get(i).getClass() == c.allVar.get(36).getClass()) {
						WindSpeed w = (WindSpeed) c.allVar.get(i);
						switch(unitSpeed) {
						case(1):
							if(month.equals(w.getMonth())) {
								total += w.getmPerSec();
							}
							break;
						case(2):
							if(month.equals(w.getMonth())) {
								total += w.getKmPerHour();
							}
							break;
						}
					}
				}
			}
		}
		if(!(inside)) {
			System.out.println("Name is invalid! So empty value is : ");
		}
		return (total/3);
	}
	//Fourth Query
	private double fourthOpt() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Select city");
		String citySelect = scan.next();
		int total = 0;
		boolean inside = false;
		//Humidity for the cities
		for(City c: this.cityArrList) {
			if(citySelect.equals(c.getName())) {
				inside = true;
				for(int i = 0; i<144; i++) {
					if(c.allVar.get(i).getClass() == c.allVar.get(72).getClass()) {
						Humidity h = (Humidity) c.allVar.get(i);
						total += h.getHumPerc();
					}
				}
			}
		}
		if(!(inside)) {
			System.out.println("Name is invalid! So empty value is : ");
		}
		
		return total/36;
	}
	//Fifth Option
	private int fifthOpt() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Select city");
		String citySelect = scan.next();
		System.out.println("[1]2020 [2]2021 [3]2022");
		int year = scan.nextInt();
		System.out.println("[1]Low [2]Medium [3]High");
		int inden = scan.nextInt();
		int total = 0;
		boolean inside = false;
		//Radiation Indensity for the cities
		for(City c: this.cityArrList) {
			if(citySelect.equals(c.getName())) {
				inside = true;
				for(int i = 0; i<144; i++) {
					if(c.allVar.get(i).getClass() == c.allVar.get(108).getClass()) {
						RadiationAbsorbtion r = (RadiationAbsorbtion) c.allVar.get(i);
						switch(inden) {
						case(1):
							if(r.getYear() == 2019+year) {
								if(r.getRandIndString().equals("Low")) {
									total++;
								}
							}
							break;
						case(2):
							if(r.getYear() == 2019+year) {
								if(r.getRandIndString().equals("Medium")) {
									total++;
								}
							}
							break;
						case(3):
							if(r.getYear() == 2019+year) {
								if(r.getRandIndString().equals("High")) {
									total++;
								}
							}
							break;
						}
					}
				}
		}
		}
		if(!(inside)) {
			System.out.println("Name is invalid! So empty value is : ");
		}
		return total;
	}
	//Sixth Query
	private double sixthOpt() {
		Scanner scan = new Scanner(System.in);
		System.out.println("Select city");
		String citySelect = scan.next();
		System.out.println("[1]2020 [2]2021 [3]2022");
		int year = scan.nextInt();
		System.out.println("Select month");
		String month = scan.next();
		double feltTemp = 0;
		double temp = 0;
		double windMS = 0;
		double hum = 0;
		double unitAbs = 0;
		boolean inside = false;
		//Felt temperature calculation for Cities
		for(City c: this.cityArrList) {
			if(citySelect.equals(c.getName())) {
				inside = true;
				for(int i = 0; i<144; i++) {
					if((c.allVar.get(i).getMonth().equals(month))&&(c.allVar.get(i).getYear() == year+2019)) {
						if(c.allVar.get(i).getClass() == c.allVar.get(0).getClass()) {
							Temperature temper = (Temperature) c.allVar.get(i);
							temp = temper.getCelciusMeasurement();
						}
						else if(c.allVar.get(i).getClass() == c.allVar.get(36).getClass()) {
							WindSpeed wind = (WindSpeed) c.allVar.get(i);
							 windMS = wind.getmPerSec();
						}
						else if(c.allVar.get(i).getClass() == c.allVar.get(72).getClass()) {
							Humidity humid = (Humidity) c.allVar.get(i);
							 hum = humid.getHumPerc()/100;
						}
						else if(c.allVar.get(i).getClass() == c.allVar.get(108).getClass()) {
							RadiationAbsorbtion rad = (RadiationAbsorbtion) c.allVar.get(i);
							unitAbs = rad.getUnitAbsVal();
						}
					}
					
				}
		}
		}
		if(!(inside)) {
			System.out.println("Name is invalid! So empty value is : ");
		}
		feltTemp = temp + (0.3 * hum) - (0.7 * (unitAbs / (windMS + 10)));
		return feltTemp;
	}
	
}
