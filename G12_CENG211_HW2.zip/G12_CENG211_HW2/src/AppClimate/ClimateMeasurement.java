package AppClimate;

public class ClimateMeasurement {
	//default year 
	private int year = 2020;
	//default monthCounter
	private static int monthCounter = 0;
	private String month;
	//Adding Constructor 
	public ClimateMeasurement() {
		setMonthCounter(getMonthCounter()+1);
		//Setting year depending on the monthCounter
		if((12<monthCounter)&&(monthCounter<25)) {
			this.setYear(2021);
		}
		if((24<monthCounter)&&(monthCounter<37)) {
			this.setYear(2022);
		}
		//Setting month depending on the monthCounter
		if((monthCounter == 1)||(monthCounter == 13)||(monthCounter == 25)) {
			this.setMonth("January");}
		if((monthCounter == 2)||(monthCounter == 14)||(monthCounter == 26)) {
			this.setMonth("February");}
		if((monthCounter == 3)||(monthCounter == 15)||(monthCounter == 27)) {
			this.setMonth("March");}
		if((monthCounter == 4)||(monthCounter == 16)||(monthCounter == 28)) {
			this.setMonth("April");}
		if((monthCounter == 5)||(monthCounter == 17)||(monthCounter == 29)) {
			this.setMonth("May");}
		if((monthCounter == 6)||(monthCounter == 18)||(monthCounter == 30)) {
			this.setMonth("June");}
		if((monthCounter == 7)||(monthCounter == 19)||(monthCounter == 31)) {
			this.setMonth("July");}
		if((monthCounter == 8)||(monthCounter == 20)||(monthCounter == 32)) {
			this.setMonth("August");}
		if((monthCounter == 9)||(monthCounter == 21)||(monthCounter == 33)) {
			this.setMonth("September");}
		if((monthCounter == 10)||(monthCounter == 22)||(monthCounter == 34)) {
			this.setMonth("October");}
		if((monthCounter == 11)||(monthCounter == 23)||(monthCounter == 35)) {
			this.setMonth("November");}
		if((monthCounter == 12)||(monthCounter == 24)||(monthCounter == 36)) {
			this.setMonth("December");}	
		// Resetting the monthCounter after reaching 36 months
		if(monthCounter >= 36) {
			this.setMonthCounter(0);
		}
	}
	//getters-setters for the months , year , monthCounter
	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getMonthCounter() {
		return monthCounter;
	}
	public void setMonthCounter(int monthCounter) {
		ClimateMeasurement.monthCounter = monthCounter;
	}
	
}
