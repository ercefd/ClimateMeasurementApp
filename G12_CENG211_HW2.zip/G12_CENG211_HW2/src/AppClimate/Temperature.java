package AppClimate;

import java.util.Random;

public class Temperature extends ClimateMeasurement {
	// Fields to store temperature measurements in different units
	private double celciusMeasurement;
	private double fahrenheitMeasurement;
	private double kelvinMeasurement;
	
	 // Constructor
	public Temperature() {
		// Call the superclass constructor
		super();
		
		// Generate a random Celsius measurement between -40 and 50 degrees
		Random r = new Random();
		this.setCelciusMeasurement(-40 + 90 * r.nextDouble());
		
		// Calculate and set corresponding Fahrenheit and Kelvin measurements
		this.setFahrenheitMeasurement(this.CtoF(this.getCelciusMeasurement()));
		this.setKelvinMeasurement(this.CtoK(this.getCelciusMeasurement()));
	}
	
	// Method to convert Celsius to Fahrenheit
	public double CtoF(double celciusMeasurement) {
		return (celciusMeasurement * 9/5)+32;
	}
	
	// Method to convert Celsius to Kelvin
	public double CtoK(double celciusMeasurement) {
		return (celciusMeasurement + 273.15);
		
	}
	
	
	// Getter and setter methods for Celsius measurement
	public double getCelciusMeasurement() {
		return celciusMeasurement;
	}

	public void setCelciusMeasurement(double celciusMeasurement) {
		this.celciusMeasurement = celciusMeasurement;
	}

	// Getter and setter methods for Fahrenheit measurement
	public double getFahrenheitMeasurement() {
		return fahrenheitMeasurement;
	}

	public void setFahrenheitMeasurement(double fahrenheitMeasurement) {
		this.fahrenheitMeasurement = fahrenheitMeasurement;
	}
	
	// Getter and setter methods for Kelvin measurement
	public double getKelvinMeasurement() {
		return kelvinMeasurement;
	}

	public void setKelvinMeasurement(double kelvinMeasurement) {
		this.kelvinMeasurement = kelvinMeasurement;
	}

	
}
